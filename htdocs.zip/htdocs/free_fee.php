<?
	$age = 68;
	$fee = "5,000원";

	if($age >= 65)
	{
		$fee = "무료";
	}

	echo "나이 : $age 세, 입장료 : $fee";
?>
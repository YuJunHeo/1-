<div class="menus"><a href="./memo/memo.php" style="font-size:20px;margin-left:50px;">shopping</a></div>
<div class="menus"><a href="./greet/list.php" style="font-size:20px;margin-left:50px;">sns</a></div>
<div class="menus"><a href="./concert/list.php" style="font-size:20px;margin-left:50px;">music</a></div>
<div class="menus"><a href="./download/list.php" style="font-size:20px;margin-left:50px;">post</a></div>
<div class="menus"><a href="./free/list.php"><img src="./img/menu05.gif" border="0"></a></div>
<div class="menus"><a href="./qna/list.php"><img src="./img/menu06.gif" border="0"></a></div>
<div class="menus"><a href="#"><img src="./img/menu07.gif" onclick="window.open('./survey/survey.php', '','scrollbars=no, toolbars=no,width=180,height=230')" border="0"></a></div>
<div class="menus" style="margin-left:10%;"><a href=".././memo/shopping.php" style="font-size:20px;margin-left:50px;"><b>SHOPPING</b></a></div>
<div class="menus"style="margin-left:10%;"><a href=".././greet/sns.php" style="font-size:20px;margin-left:50px;"><b>SNS<b></a></div>
<div class="menus"style="margin-left:10%;"><a href=".././concert/music.php" style="font-size:20px;margin-left:50px;"><b>MUSIC</b></a></div>
<div class="menus"style="margin-left:10%;"><a href=".././free/post.php" style="font-size:20px;margin-left:50px;"><b>POST</b></a></div>
<div class="menus"><a href="./memo/memo.php" style="font-size:20px;margin-left:50px;">shopping</a></div>
<div class="menus"><a href="./greet/list.php" style="font-size:20px;margin-left:50px;">sns</a></div>
<div class="menus"><a href="./concert/list.php" style="font-size:20px;margin-left:50px;">music</a></div>
<div class="menus"><a href="./download/list.php" style="font-size:20px;margin-left:50px;">post</a></div>

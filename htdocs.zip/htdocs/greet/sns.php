﻿<? 
	@session_start(); 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head> 
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/greet.css" rel="stylesheet" type="text/css" media="all">
<style>
.Nrlbutton {
		  padding: 100px 100px;
		  font-size: 24px;
		  text-align: center;
		  cursor: pointer;
		  outline: none;
		  color: black;
		  border-radius: 15px;
		  border-color:black;
		  box-shadow: 0 9px #999;
		  display: block;
		  font-size: 40px;
		  font-weight: bold;
		margin-left:10%;
	 		}
		.Nrlbutton:hover {background-color: #3e8e41}

		.Nrlbutton:active {
		  background-color: #3e8e41;
		  box-shadow: 0 5px #666;
		  transform: translateY(4px);
			}
</style>
</head>
<?
	include "../lib/dbconn.php";

	$scale=10;			// 한 화면에 표시되는 글 수

    if ($mode=="search")
	{
		if(!$search)
		{
			echo("
				<script>
				 window.alert('검색할 단어를 입력해 주세요!');
			     history.go(-1);
				</script>
			");
			exit;
		}

		$sql = "select * from greet where $find like '%$search%' order by num desc";
	}
	else
	{
		$sql = "select * from greet order by num desc";
	}

	$result = mysql_query($sql, $connect);

	$total_record = @mysql_num_rows($result); // 전체 글 수

	// 전체 페이지 수($total_page) 계산 
	if ($total_record % $scale == 0)     
		$total_page = floor($total_record/$scale);      
	else
		$total_page = floor($total_record/$scale) + 1; 
 
	if (!$page)                 // 페이지번호($page)가 0 일 때
		$page = 1;              // 페이지 번호를 1로 초기화
 
	// 표시할 페이지($page)에 따라 $start 계산  
	$start = ($page - 1) * $scale;      

	$number = $total_record - $start;
?>
<body>
<div id="wrap">
  <div id="header">
    <? include "../lib/H login2.php"; ?>
  </div>
<div id="menu">
	<? include "../lib/H menu2.php"; ?>
  </div> 
<br>
<br>
<br>
<br>
<br>
<table style="margin-left:10%;width:100%">
	<tr>
		<td><a href="https://www.facebook.com/"target="_blank"><button class="Nrlbutton">페이스북</button></a></td>
		<td><a href="http://https://www.instagram.com/"target="_blank"><button class="Nrlbutton">인스타그램</button></a></td>
	</tr>
	<tr>
		<td><a href="https://twitter.com/"target="_blank"><button class="Nrlbutton">트위터</button></a></td>
		<td><a href="https://accounts.kakao.com/login/kakaostory"target="_blank"><button class="Nrlbutton">카카오스토리</button></a></td>	
	</tr>


</body>
</html>

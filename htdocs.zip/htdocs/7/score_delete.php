﻿<?
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "heo_db";

// 데이터베이스 연결
$conn = new mysqli($servername,$username,$password,$dbname);

$sql = "DELETE FROM stud_score WHERE  num=$_GET[num]";
$result=$conn->query($sql);

?>
<script type="text/javascript">
 location.href="score_list.php";

</script>
   // 데이터베이스 데이터 출력 완료
          
 ?>

 </table>

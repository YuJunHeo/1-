﻿<?
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "heo_db";

// 데이터베이스 연결
$conn = new mysqli($servername,$username,$password,$dbname);

$name = $_POST[name];
$sub1 = $_POST[sub1];
$sub2 = $_POST[sub2];
$sub3 = $_POST[sub3];
$sub4 = $_POST[sub4];
$sub5 = $_POST[sub5];

 if ($_GET[mode] == "insert")                            // 데이터 입력 모드  
  {
    $sum = $sub1 + $sub2 + $sub3 + $sub4 + $sub5;   // 합계 계산
    $avg = $sum/5;                                  // 평균 계산
    $sql = "insert into stud_score (name, sub1, sub2, sub3, sub4, sub5, sum, avg) values";
    $sql.= "('$name', $sub1, $sub2, $sub3, $sub4, $sub4, $sum, $avg)";     
    //$result = mysql_query($sql, $connect);
    $result = $conn->query($sql); //에러 처리 필요~!
  }

?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<h3>1) 성적 입력 하기</h3>
<form action="score_list.php?mode=insert" method='post'>
<table width="800" border="1" cellpadding="5">
<tr><td> 이름 : <input type="text" size="6" name="name">&nbsp;
  국어 : <input type="text" size="3" name="sub1">&nbsp;
  영어 : <input type="text" size="3" name="sub2">&nbsp;
  수학 : <input type="text" size="3" name="sub3">&nbsp;
  과학: <input type="text" size="3" name="sub4">&nbsp;
  사회 : <input type="text" size="3" name="sub5">
  </td>
  <td align="center">
  <input type="submit" value="입력하기"> 
  </td>
</tr>
</table>
</form>

<p>
<h3>2) 성적 출력 하기</h3>
<p><a href ="score_list.php?mode=big_first">[성적순 정렬]</a>
<a href ="score_list.php?mode=small_first">[성적역순 정렬]</a></p>
<p>
<!-- 제목 표시 시작 -->
<table width="720" border="1" cellpadding="5">
<tr align="center" bgcolor="#eeeeee">
  <td><b>번호</b></td>
  <td><b>이름</b></td>
  <td><b>국어</b></td>
  <td><b>영어</b></td>
  <td><b>수학</b></td>
  <td><b>과학</b></td>
  <td><b>사회</b></td>
  <td><b>총합</b></td>
  <td><b>평균</b></td>
  <td><b>삭제</b></td>
</tr>

<!-- 제목 표시 끝 -->

<?
  // select 명령 저장
  if ($_GET[mode] == "big_first")                // 성적순 정렬(내림차순)
    $sql = "select * from stud_score order by sum desc";
  else if ($_GET[mode] == "small_first")         // 성적순 정렬(오름차순)
    $sql = "select * from stud_score order by sum";
  else
    $sql = "select * from stud_score";
   
    $result = $conn->query($sql); 
      $count = 1;                              // 성적 출력하기의
  // 데이터베이스 데이터 출력 시작
  while ($row = $result->fetch_assoc())
  {
    $avg = round($row[avg], 1);

    $num = $row[num];

    echo "<tr align='center'>
       <td> $count </td>
       <td> $row[name] </td>
       <td> $row[sub1] </td>
       <td> $row[sub2] </td>
       <td> $row[sub3] </td>
       <td> $row[sub4] </td>
       <td> $row[sub5] </td>
       <td> $row[sum] </td>
       <td> $avg </td>
       <td> <a href='score_delete.php?num=$num'>[삭제]</a></td>
    </tr>";
   

     $count++;
   }

<?
	$a = 7;
	$b = 8;

	$a ++;
	$b --;

	$b = $a * $b + 2;

	$c = $a + $b;

	echo "a : $a, b : $b, c : $c<br>";

	$c = $a % $b;

	$b = $a + 2;

	$a = $a * 3;

	echo "a : $a, b : $b, c : $c";
?>
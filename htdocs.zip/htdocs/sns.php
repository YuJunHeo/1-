<!DOCTYPE html>
<html>
<head>
	<title>sns</title>
	<style>
		ul{
			list-style: none;
			display: flex;
			justify-content: center;
			padding: 20px;
			background-color: black;

		}
		a{
			color: white;
			text-decoration:none;
			padding:20px 150px;
			float:left;
		}
	</style>
</head>
<body>
	<div>
		<nav>
			<ul>
				<li><a href=""><b>쇼핑</b></a></li>
				<li><a href=""><b>SNS</b></a></li>
				<li><a href=""><b>음악</b></a></li>
				<li><a href=""><b>즐겨찾기</b></a></li>
			</ul>
		</nav>
	</div>
</body>
</html>
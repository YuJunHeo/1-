<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?
	echo"반갑습니다. <br>";
	echo"행복한 하루 되세요!";
?>
</body>
</html>
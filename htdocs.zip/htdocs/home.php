<?
	session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/common.css">
</head>

<body>
<div id="wrap">
	<div id="header">
    <? include "./lib/H login.php"; ?><br>
	</div>

<div>
</div>
	<div id="menu">
	<? include "./lib/H menu.php"; ?>
	</div>

  <div id="content">
		<center><div id="main_img"><img src="./img/로고.jpg" style="width:80%;height:100%;margin-top:10%;"></div></center>
  </div>
</div>

</body>
</html>
